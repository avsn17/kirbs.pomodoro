#!/usr/bin/env bash
# ============================================================
#  🌸 kirbs.pomodoro — self-deploy script
#  Pilot: avsn17
#  Usage: chmod +x deploy.sh && ./deploy.sh
# ============================================================

set -euo pipefail

# ── colours ──────────────────────────────────────────────────
RESET='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'
STAR='\033[38;5;214m'    # amber / star colour
PINK='\033[38;5;205m'
TEAL='\033[38;5;80m'
RED='\033[38;5;196m'
GREEN='\033[38;5;120m'
GRAY='\033[38;5;240m'

# ── helpers ───────────────────────────────────────────────────
log()     { echo -e "${STAR}${BOLD}[kirbs]${RESET} $*"; }
ok()      { echo -e "${GREEN}  ✓ $*${RESET}"; }
info()    { echo -e "${TEAL}  → $*${RESET}"; }
warn()    { echo -e "${PINK}  ⚠ $*${RESET}"; }
err()     { echo -e "${RED}${BOLD}  ✕ $*${RESET}"; }
dim()     { echo -e "${GRAY}${DIM}    $*${RESET}"; }
divider() { echo -e "${GRAY}${DIM}  ────────────────────────────────────────${RESET}"; }

kirby_say() {
  echo -e ""
  echo -e "${STAR}${BOLD}  <(${1})>${RESET}  ${2}"
  echo -e ""
}

# ── banner ────────────────────────────────────────────────────
clear
echo -e "${STAR}${BOLD}"
cat << 'EOF'
  ██╗  ██╗██╗██████╗ ██████╗ ███████╗
  ██║ ██╔╝██║██╔══██╗██╔══██╗██╔════╝
  █████╔╝ ██║██████╔╝██████╔╝███████╗
  ██╔═██╗ ██║██╔══██╗██╔══██╗╚════██║
  ██║  ██╗██║██║  ██║██████╔╝███████║
  ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝
   .pomodoro — self-deploy to Vercel
EOF
echo -e "${RESET}"
echo -e "${GRAY}${DIM}  Pilot: avsn17 · cosmic focus timer${RESET}"
echo ""

# ── step 0: check we're in the right place ───────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

log "Starting self-deploy sequence..."
divider

# ── step 1: check dependencies ───────────────────────────────
echo ""
log "Checking dependencies..."

check_dep() {
  if command -v "$1" &>/dev/null; then
    ok "$1 found ($(command -v "$1"))"
    return 0
  else
    return 1
  fi
}

# git
if ! check_dep git; then
  err "git not found. Install: https://git-scm.com"
  exit 1
fi

# node / npm (needed for vercel CLI)
if ! check_dep node; then
  warn "Node.js not found — attempting install via nvm..."
  if check_dep curl; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    export NVM_DIR="$HOME/.nvm"
    # shellcheck source=/dev/null
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    nvm install --lts
    nvm use --lts
  else
    err "curl not found either. Install Node.js manually: https://nodejs.org"
    exit 1
  fi
fi

# npm
if ! check_dep npm; then
  err "npm not found. It should come with Node.js."
  exit 1
fi

# vercel CLI
if ! check_dep vercel; then
  warn "Vercel CLI not found — installing globally..."
  npm install -g vercel
  ok "vercel CLI installed"
else
  ok "vercel CLI found"
  # Check for updates silently
  CURRENT_VER=$(vercel --version 2>/dev/null | head -1 || echo "unknown")
  dim "version: $CURRENT_VER"
fi

divider

# ── step 2: check / init git repo ────────────────────────────
echo ""
log "Checking git status..."

if [ ! -d ".git" ]; then
  warn "Not a git repo — initialising..."
  git init
  ok "git init done"
fi

# check for remote
REMOTE_URL=""
if git remote get-url origin &>/dev/null; then
  REMOTE_URL=$(git remote get-url origin)
  ok "Remote found: $REMOTE_URL"
else
  warn "No git remote 'origin' configured."
  echo ""
  echo -e "  ${TEAL}Enter your GitHub repo URL${RESET}"
  echo -e "  ${GRAY}(e.g. https://github.com/avsn17/kirbs.pomodoro.git)${RESET}"
  echo -ne "  > "
  read -r REMOTE_URL
  if [ -z "$REMOTE_URL" ]; then
    warn "Skipping remote — will deploy from local directory only."
  else
    git remote add origin "$REMOTE_URL"
    ok "Remote added: $REMOTE_URL"
  fi
fi

divider

# ── step 3: stage & commit ────────────────────────────────────
echo ""
log "Staging files..."

# Check if there's anything to commit
git add -A

if git diff --cached --quiet; then
  ok "Nothing new to commit — working tree clean"
  COMMITTED=false
else
  # Auto-generate commit message
  CHANGED_FILES=$(git diff --cached --name-only | wc -l | tr -d ' ')
  TIMESTAMP=$(date '+%Y-%m-%d %H:%M')
  COMMIT_MSG="feat: web edition deploy · ${CHANGED_FILES} files · ${TIMESTAMP}"

  echo ""
  echo -e "  ${TEAL}Commit message:${RESET}"
  echo -e "  ${GRAY}\"${COMMIT_MSG}\"${RESET}"
  echo -ne "  Press Enter to use this, or type a custom message: "
  read -r CUSTOM_MSG
  [ -n "$CUSTOM_MSG" ] && COMMIT_MSG="$CUSTOM_MSG"

  git commit -m "$COMMIT_MSG"
  ok "Committed: \"$COMMIT_MSG\""
  COMMITTED=true
fi

# ── step 4: push to GitHub (if remote set) ───────────────────
if [ -n "$REMOTE_URL" ]; then
  echo ""
  log "Pushing to GitHub..."
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")
  info "Branch: $BRANCH"

  if git push -u origin "$BRANCH" 2>&1; then
    ok "Pushed to $REMOTE_URL"
  else
    warn "Push failed (maybe first push needs --force or branch rename)"
    echo -ne "  Try force push? (y/N): "
    read -r FORCE_PUSH
    if [[ "$FORCE_PUSH" =~ ^[Yy]$ ]]; then
      git push -u origin "$BRANCH" --force
      ok "Force pushed"
    else
      warn "Skipping push — will still deploy from local"
    fi
  fi
fi

divider

# ── step 5: Vercel auth check ─────────────────────────────────
echo ""
log "Checking Vercel auth..."

if vercel whoami &>/dev/null 2>&1; then
  VERCEL_USER=$(vercel whoami 2>/dev/null || echo "unknown")
  ok "Logged in as: $VERCEL_USER"
else
  warn "Not logged into Vercel — launching login..."
  echo ""
  echo -e "  ${TEAL}A browser window will open for Vercel login.${RESET}"
  echo -e "  ${GRAY}If it doesn't open, copy the URL shown in the terminal.${RESET}"
  echo ""
  vercel login
  ok "Vercel login complete"
fi

divider

# ── step 6: deploy ────────────────────────────────────────────
echo ""
kirby_say "!)" "Deploying to Vercel..."

DEPLOY_FLAGS="--yes"
PROD_FLAG=""

# Ask for production deploy
echo -ne "  ${TEAL}Deploy to production?${RESET} (y/N, default = preview): "
read -r IS_PROD
if [[ "$IS_PROD" =~ ^[Yy]$ ]]; then
  PROD_FLAG="--prod"
  info "Deploying to PRODUCTION"
else
  info "Deploying to PREVIEW (pass --prod to go live)"
fi

echo ""
info "Running: vercel $DEPLOY_FLAGS $PROD_FLAG"
echo ""

# Run deploy and capture URL
DEPLOY_OUTPUT=$(vercel $DEPLOY_FLAGS $PROD_FLAG 2>&1)
DEPLOY_EXIT=$?

echo "$DEPLOY_OUTPUT"

if [ $DEPLOY_EXIT -ne 0 ]; then
  err "Vercel deploy failed (exit $DEPLOY_EXIT)"
  echo ""
  err "Common fixes:"
  dim "• Run: vercel logout && vercel login"
  dim "• Check vercel.json is valid JSON"
  dim "• Make sure public/index.html exists"
  dim "• Try: vercel --debug"
  exit 1
fi

# Extract deployed URL
DEPLOY_URL=$(echo "$DEPLOY_OUTPUT" | grep -E 'https://[a-zA-Z0-9._-]+\.vercel\.app' | tail -1 | tr -d '[:space:]')

divider

# ── step 7: success ───────────────────────────────────────────
echo ""
kirby_say "* )" "MISSION COMPLETE!! POYO!"
echo ""

if [ -n "$DEPLOY_URL" ]; then
  echo -e "  ${STAR}${BOLD}🚀 Deployed:${RESET} ${TEAL}${BOLD}${DEPLOY_URL}${RESET}"
else
  echo -e "  ${STAR}${BOLD}🚀 Deploy complete!${RESET} Check Vercel dashboard for URL."
fi

echo ""
echo -e "  ${GRAY}${DIM}Shortcuts once live:${RESET}"
echo -e "  ${GRAY}${DIM}  Space = pause · R = reset · W = wisdom · T = tasks · A = ambient${RESET}"
echo ""
echo -e "${STAR}${DIM}  May your productivity journey be guided by wisdom. 🌌${RESET}"
echo ""

# ── optional: open in browser ────────────────────────────────
if [ -n "$DEPLOY_URL" ]; then
  echo -ne "  Open in browser? (y/N): "
  read -r OPEN_BROWSER
  if [[ "$OPEN_BROWSER" =~ ^[Yy]$ ]]; then
    if command -v xdg-open &>/dev/null; then
      xdg-open "$DEPLOY_URL"
    elif command -v open &>/dev/null; then
      open "$DEPLOY_URL"
    else
      info "Can't auto-open browser. Visit: $DEPLOY_URL"
    fi
  fi
fi

echo ""
