# 🌸 kirbs.pomodoro — Web Edition

> Cosmic focus timer · Kirby energy · Galactic ranks · Ambient sounds
> Pilot: **avsn17** · Deploy target: Vercel (static)

---

## File Structure

```
kirbs.pomodoro/
├── public/
│   ├── index.html          ← Main app shell
│   ├── css/
│   │   └── style.css       ← All styles (dark cosmic theme)
│   └── js/
│       ├── data.js         ← Ranks, wisdom quotes, sound defs, localStorage state
│       ├── audio.js        ← Web Audio API ambient engine (rain/forest/fire/café/ocean/space)
│       ├── timer.js        ← Pomodoro timer, Kirby track, confetti, rank-up modal
│       ├── tasks.js        ← Task board, INHALE to complete, XP system
│       ├── wisdom.js       ← Wisdom chat (Iroh, Brontë, Kant, Kirby, vibe, heroic, lyrics)
│       ├── ranks.js        ← Galactic rank display + progress card
│       └── app.js          ← Init, tab switching, starfield, keyboard shortcuts
├── vercel.json             ← Static deployment config
└── README.md
```

---

## Deploy to Vercel

### Option A — Drop files into existing repo

1. Copy the `public/` folder and `vercel.json` into your `kirbs.pomodoro` repo root
2. Delete or back up the old `vercel.json`
3. Push to GitHub:
   ```bash
   git add public/ vercel.json
   git commit -m "feat: web edition — static Vercel deploy"
   git push origin main
   ```
4. Go to [vercel.com](https://vercel.com) → Import project → select `kirbs.pomodoro`
5. Framework preset: **Other** · Root directory: *(leave blank)*
6. Click Deploy → live at `kirbs-pomodoro.vercel.app`

### Option B — New Vercel project from scratch

```bash
npm i -g vercel
cd /path/to/kirbs.pomodoro
vercel
# Follow prompts: framework = Other, root = .
```

---

## Features

| Tab | What it does |
|-----|-------------|
| ⏱ Timer | Kirby slides across track · meters = minutes · break auto-starts |
| ✅ Tasks | POYO! to add · INHALE to complete · +20 XP each |
| 💬 Wisdom | 8 sources: Iroh · Brontë · Kant · Kirby · Vibe · Heroic · Lyrics · Wisdom |
| 🏆 Ranks | 6 galactic ranks · rank-up popup with confetti |
| 🎵 Ambient | 6 Web Audio sounds · individual volume mix |
| 📊 Stats | Total meters · heatmap · session log |

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Pause / Resume |
| `R` | Reset timer |
| `S` | Stats tab |
| `W` | Wisdom tab |
| `T` | Tasks tab |
| `A` | Ambient tab |
| `Esc` | Close modal / sidebar |

---

*May your productivity journey be guided by wisdom. 🌌*
*— Cosmic Kirbs · avsn17*
