// ===== KIRBY SVG MASCOT =====
// Draws a cute Kirby in pure SVG, injected wherever needed

const KIRBY_MOODS = {
  idle:   { mouth: 'smile',  eyes: 'happy',  blush: true,  bow: true,  color: '#ff85c2', cheek: '#ffb3d9' },
  active: { mouth: 'open',   eyes: 'determined', blush: false, bow: true, color: '#ff85c2', cheek: '#ffb3d9' },
  paused: { mouth: 'hmm',    eyes: 'sleepy', blush: true,  bow: true,  color: '#c97eff', cheek: '#ddb4ff' },
  done:   { mouth: 'big',    eyes: 'star',   blush: true,  bow: true,  color: '#ff85c2', cheek: '#ffb3d9' },
  break:  { mouth: 'zzz',    eyes: 'closed', blush: true,  bow: true,  color: '#a78bfa', cheek: '#c4b5fd' },
};

let currentMood = 'idle';

function buildKirbySVG(mood = 'idle', size = 80) {
  const m = KIRBY_MOODS[mood] || KIRBY_MOODS.idle;
  const s = size;
  const cx = s / 2, cy = s / 2 + 2;
  const r = s * 0.40;

  // Eyes
  let eyes = '';
  if (m.eyes === 'happy') {
    // cute arch eyes
    eyes = `
      <path d="M${cx-r*.28} ${cy-r*.18} Q${cx-r*.17} ${cy-r*.32} ${cx-r*.06} ${cy-r*.18}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="none" stroke-linecap="round"/>
      <path d="M${cx+r*.06} ${cy-r*.18} Q${cx+r*.17} ${cy-r*.32} ${cx+r*.28} ${cy-r*.18}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="none" stroke-linecap="round"/>`;
  } else if (m.eyes === 'determined') {
    eyes = `
      <ellipse cx="${cx-r*.17}" cy="${cy-r*.18}" rx="${r*.12}" ry="${r*.15}" fill="#3a1f5c"/>
      <ellipse cx="${cx+r*.17}" cy="${cy-r*.18}" rx="${r*.12}" ry="${r*.15}" fill="#3a1f5c"/>
      <ellipse cx="${cx-r*.17}" cy="${cy-r*.22}" rx="${r*.06}" ry="${r*.06}" fill="#fff" opacity=".7"/>
      <ellipse cx="${cx+r*.17}" cy="${cy-r*.22}" rx="${r*.06}" ry="${r*.06}" fill="#fff" opacity=".7"/>`;
  } else if (m.eyes === 'star') {
    const star = (x, y, rs) => {
      let d = '';
      for (let i = 0; i < 10; i++) {
        const angle = (i * Math.PI) / 5 - Math.PI / 2;
        const rad = i % 2 === 0 ? rs : rs * 0.45;
        const px = x + Math.cos(angle) * rad;
        const py = y + Math.sin(angle) * rad;
        d += (i === 0 ? 'M' : 'L') + px + ' ' + py;
      }
      return d + 'Z';
    };
    eyes = `<path d="${star(cx-r*.18, cy-r*.18, r*.14)}" fill="#ffe055"/>
            <path d="${star(cx+r*.18, cy-r*.18, r*.14)}" fill="#ffe055"/>`;
  } else if (m.eyes === 'sleepy') {
    eyes = `
      <path d="M${cx-r*.28} ${cy-r*.22} Q${cx-r*.17} ${cy-r*.1} ${cx-r*.06} ${cy-r*.22}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="rgba(58,31,92,.25)" stroke-linecap="round"/>
      <path d="M${cx+r*.06} ${cy-r*.22} Q${cx+r*.17} ${cy-r*.1} ${cx+r*.28} ${cy-r*.22}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="rgba(58,31,92,.25)" stroke-linecap="round"/>`;
  } else if (m.eyes === 'closed') {
    eyes = `
      <path d="M${cx-r*.28} ${cy-r*.2} Q${cx-r*.17} ${cy-r*.1} ${cx-r*.06} ${cy-r*.2}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="none" stroke-linecap="round"/>
      <path d="M${cx+r*.06} ${cy-r*.2} Q${cx+r*.17} ${cy-r*.1} ${cx+r*.28} ${cy-r*.2}" stroke="#3a1f5c" stroke-width="${s*.03}" fill="none" stroke-linecap="round"/>`;
  }

  // Mouth
  let mouth = '';
  if (m.mouth === 'smile') {
    mouth = `<path d="M${cx-r*.2} ${cy+r*.08} Q${cx} ${cy+r*.26} ${cx+r*.2} ${cy+r*.08}" stroke="#3a1f5c" stroke-width="${s*.025}" fill="none" stroke-linecap="round"/>`;
  } else if (m.mouth === 'open') {
    mouth = `<ellipse cx="${cx}" cy="${cy+r*.16}" rx="${r*.16}" ry="${r*.1}" fill="#3a1f5c"/>
             <path d="M${cx-r*.14} ${cy+r*.18} Q${cx} ${cy+r*.3} ${cx+r*.14} ${cy+r*.18}" stroke="#3a1f5c" stroke-width="${s*.02}" fill="none"/>`;
  } else if (m.mouth === 'big') {
    mouth = `<path d="M${cx-r*.24} ${cy+r*.06} Q${cx-r*.1} ${cy+r*.28} ${cx} ${cy+r*.3} Q${cx+r*.1} ${cy+r*.28} ${cx+r*.24} ${cy+r*.06}" fill="#3a1f5c"/>
             <path d="M${cx-r*.18} ${cy+r*.08} Q${cx} ${cy+r*.18} ${cx+r*.18} ${cy+r*.08}" stroke="#ff5f9c" stroke-width="${s*.015}" fill="none"/>`;
  } else if (m.mouth === 'hmm') {
    mouth = `<path d="M${cx-r*.16} ${cy+r*.14} Q${cx} ${cy+r*.2} ${cx+r*.16} ${cy+r*.14}" stroke="#3a1f5c" stroke-width="${s*.025}" fill="none" stroke-linecap="round"/>`;
  } else if (m.mouth === 'zzz') {
    mouth = `<path d="M${cx-r*.12} ${cy+r*.14} Q${cx} ${cy+r*.2} ${cx+r*.12} ${cy+r*.14}" stroke="#3a1f5c" stroke-width="${s*.022}" fill="none" stroke-linecap="round"/>
             <text x="${cx+r*.28}" y="${cy-r*.1}" font-size="${s*.12}" fill="#c4b5fd" font-family="DM Sans,sans-serif" font-weight="bold">z</text>
             <text x="${cx+r*.4}" y="${cy-r*.22}" font-size="${s*.09}" fill="#c4b5fd" font-family="DM Sans,sans-serif" font-weight="bold">z</text>`;
  }

  // Blush
  const blush = m.blush ? `
    <ellipse cx="${cx-r*.38}" cy="${cy+r*.08}" rx="${r*.14}" ry="${r*.08}" fill="${m.cheek}" opacity=".7"/>
    <ellipse cx="${cx+r*.38}" cy="${cy+r*.08}" rx="${r*.14}" ry="${r*.08}" fill="${m.cheek}" opacity=".7"/>` : '';

  // Arms / feet
  const arms = `
    <ellipse cx="${cx-r*1.05}" cy="${cy+r*.1}" rx="${r*.22}" ry="${r*.16}" fill="${m.color}" transform="rotate(-20,${cx-r*1.05},${cy+r*.1})"/>
    <ellipse cx="${cx+r*1.05}" cy="${cy+r*.1}" rx="${r*.22}" ry="${r*.16}" fill="${m.color}" transform="rotate(20,${cx+r*1.05},${cy+r*.1})"/>`;
  const feet = `
    <ellipse cx="${cx-r*.28}" cy="${cy+r*1.06}" rx="${r*.28}" ry="${r*.16}" fill="#e05090"/>
    <ellipse cx="${cx+r*.28}" cy="${cy+r*1.06}" rx="${r*.28}" ry="${r*.16}" fill="#e05090"/>`;

  // Bow / hair accessory
  const bow = m.bow ? `
    <ellipse cx="${cx-r*.28}" cy="${cy-r*.88}" rx="${r*.22}" ry="${r*.14}" fill="#ff5fa0" transform="rotate(-20,${cx-r*.28},${cy-r*.88})"/>
    <ellipse cx="${cx+r*.04}" cy="${cy-r*.88}" rx="${r*.22}" ry="${r*.14}" fill="#ff5fa0" transform="rotate(20,${cx+r*.04},${cy-r*.88})"/>
    <circle cx="${cx-r*.12}" cy="${cy-r*.88}" r="${r*.08}" fill="#ffb3d9"/>` : '';

  // Sheen
  const sheen = `<ellipse cx="${cx-r*.2}" cy="${cy-r*.35}" rx="${r*.15}" ry="${r*.09}" fill="rgba(255,255,255,.35)" transform="rotate(-20,${cx-r*.2},${cy-r*.35})"/>`;

  return `<svg width="${s}" height="${s+s*.1}" viewBox="0 0 ${s} ${s+s*.1}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="kg${mood}" cx="40%" cy="35%" r="60%">
        <stop offset="0%" stop-color="${lighten(m.color)}"/>
        <stop offset="100%" stop-color="${m.color}"/>
      </radialGradient>
    </defs>
    ${arms}
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#kg${mood})"/>
    ${feet}
    ${blush}
    ${eyes}
    ${mouth}
    ${sheen}
    ${bow}
  </svg>`;
}

function lighten(hex) {
  // lighten a hex colour for gradient
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  const lr = Math.min(255, r + 40), lg = Math.min(255, g + 30), lb = Math.min(255, b + 40);
  return '#' + [lr,lg,lb].map(x=>x.toString(16).padStart(2,'0')).join('');
}

function setKirbyMood(mood) {
  if (currentMood === mood) return;
  currentMood = mood;
  // Update all Kirby SVG instances
  document.querySelectorAll('[data-kirby]').forEach(el => {
    const size = parseInt(el.getAttribute('data-kirby-size') || '80');
    el.innerHTML = buildKirbySVG(mood, size);
    el.className = 'kirby-svg-wrap ' + mood;
  });
  // Update speech bubbles
  const speeches = {
    idle:   'poyo ✨',
    active: 'GO GO GO! <(!)',
    paused: 'taking a breath...',
    done:   'MISSION DONE!! 🌸',
    break:  'zzz... poyo',
  };
  document.querySelectorAll('[data-kirby-speech]').forEach(el => {
    el.textContent = speeches[mood] || 'poyo';
  });
}

function spawnKirbyStars(wrap) {
  if (!wrap) return;
  const emojis = ['⭐','💫','✨','🌸','💖','🎀'];
  for (let i = 0; i < 8; i++) {
    const span = document.createElement('span');
    span.className = 'kirby-star';
    const angle = (i / 8) * 360;
    const dist = 40 + Math.random() * 30;
    const tx = Math.cos(angle * Math.PI / 180) * dist;
    const ty = Math.sin(angle * Math.PI / 180) * dist;
    span.style.cssText = `--tx:${tx}px;--ty:${ty}px;left:50%;top:50%;transform:translate(-50%,-50%);`;
    span.textContent = emojis[i % emojis.length];
    wrap.appendChild(span);
    setTimeout(() => span.remove(), 1100);
  }
}

function initKirby() {
  // Inject Kirby into every [data-kirby] element
  document.querySelectorAll('[data-kirby]').forEach(el => {
    const size = parseInt(el.getAttribute('data-kirby-size') || '80');
    el.innerHTML = buildKirbySVG('idle', size);
    el.className = 'kirby-svg-wrap idle';
    el.addEventListener('click', () => {
      spawnKirbyStars(el);
      showToast('poyo! 🌸');
    });
  });
}
