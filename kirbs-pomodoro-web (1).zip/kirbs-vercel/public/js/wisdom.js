// ===== WISDOM =====
let lastWisdomSrc = null;

function getWisdom(src) {
  document.querySelectorAll('.ws-btn').forEach(b => b.classList.remove('active'));
  event?.target?.closest('.ws-btn')?.classList.add('active');

  const pool = src === 'random'
    ? Object.values(WISDOM).flat()
    : (WISDOM[src] || WISDOM.wisdom);

  const w = pool[Math.floor(Math.random() * pool.length)];
  const qEl = document.getElementById('wisdom-quote');
  const sEl = document.getElementById('wisdom-src');

  if (qEl) {
    qEl.style.opacity = '0';
    // Kirby happy bounce
    const wk = document.getElementById('wisdom-kirby');
    if (wk) { wk.classList.add('done'); setTimeout(() => wk.classList.remove('done'), 800); }
    setTimeout(() => {
      qEl.textContent = '\u201c' + w.q + '\u201d';
      if (sEl) sEl.textContent = '— ' + w.s;
      qEl.style.opacity = '1';
      qEl.style.transition = 'opacity 0.3s';
    }, 180);
  }

  // Add to history
  ST.wisdomHistory.unshift({ q: w.q, s: w.s });
  if (ST.wisdomHistory.length > 10) ST.wisdomHistory = ST.wisdomHistory.slice(0, 10);
  saveState();
  renderWisdomHistory();
}

function renderWisdomHistory() {
  const el = document.getElementById('wh-list');
  if (!el) return;
  if (!ST.wisdomHistory.length) {
    el.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:.5rem 0">Your session quotes will appear here</div>';
    return;
  }
  el.innerHTML = ST.wisdomHistory.slice(0, 5).map(w => `
    <div class="wh-item">
      \u201c${w.q}\u201d
      <div class="wh-item-src">— ${w.s}</div>
    </div>`).join('');
}
