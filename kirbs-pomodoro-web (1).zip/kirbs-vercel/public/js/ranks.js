// ===== RANKS =====
function renderRanks() {
  const cur = getCurrentRank();

  // Progress card
  document.getElementById('rpc-emoji').textContent = cur.emoji;
  document.getElementById('rpc-name').textContent = cur.name;
  document.getElementById('rpc-total').textContent = ST.totalMeters + 'm total';

  const nextRank = RANKS.find(r => r.meters > ST.totalMeters);
  if (nextRank) {
    const needed = nextRank.meters - ST.totalMeters;
    document.getElementById('rpc-next-val').textContent = needed + 'm';
    const rangeStart = cur.meters;
    const rangeEnd = nextRank.meters;
    const pct = Math.round(((ST.totalMeters - rangeStart) / (rangeEnd - rangeStart)) * 100);
    document.getElementById('rpc-fill').style.width = pct + '%';
    document.getElementById('rpc-next-wrap').style.display = '';
  } else {
    document.getElementById('rpc-next-val').textContent = 'MAX RANK';
    document.getElementById('rpc-fill').style.width = '100%';
  }

  // Rank list
  const list = document.getElementById('ranks-list');
  if (!list) return;
  list.innerHTML = RANKS.map(r => {
    const unlocked = ST.totalMeters >= r.meters;
    const isCur = r.meters === cur.meters;
    let statusClass = 'locked', statusText = 'LOCKED';
    if (isCur) { statusClass = 'current-badge'; statusText = 'YOU ARE HERE'; }
    else if (unlocked) { statusClass = 'unlocked'; statusText = 'UNLOCKED'; }

    return `<div class="rank-row${isCur ? ' current' : ''}${!unlocked ? ' locked' : ''}">
      <div class="rank-row-emoji">${r.emoji}</div>
      <div class="rank-row-info">
        <div class="rank-row-name">${r.name}</div>
        <div class="rank-row-sub">${r.meters}m required · ${r.approx}</div>
      </div>
      <span class="rank-row-status ${statusClass}">${statusText}</span>
    </div>`;
  }).join('');
}

// ===== STATS =====
function renderStats() {
  document.getElementById('sb-total-m').textContent = ST.totalMeters;
  document.getElementById('sb-total-s').textContent = ST.sessionsTotal;

  const mins = ST.totalMeters;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  document.getElementById('sb-total-h').textContent = h + 'h ' + m + 'm';
  document.getElementById('sb-streak').textContent = ST.streak + ' 🔥';

  renderHeatmap();
  renderSessionLog();
}

function renderHeatmap() {
  const grid = document.getElementById('heat-grid');
  if (!grid) return;
  const today = new Date().getDate();
  const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
  const cells = [];
  for (let d = 1; d <= daysInMonth; d++) {
    // Mock data based on session log + current state
    let intensity = 0;
    if (d < today) intensity = Math.random() > 0.3 ? Math.random() : 0;
    else if (d === today) intensity = ST.sessions > 0 ? 0.8 : 0;
    const opacity = intensity === 0 ? 0.08 : 0.15 + intensity * 0.85;
    cells.push(`<div class="heat-cell" title="${d} ${new Date().toLocaleString('default',{month:'short'})}" style="opacity:${opacity.toFixed(2)}"></div>`);
  }
  grid.innerHTML = cells.join('');
}

function renderSessionLog() {
  const el = document.getElementById('session-log-list');
  if (!el) return;
  if (!ST.sessionLog.length) {
    el.innerHTML = '<div style="font-size:13px;color:var(--text3);padding:1rem 0">No sessions yet — start your first mission!</div>';
    return;
  }
  el.innerHTML = ST.sessionLog.slice(0, 10).map(s => `
    <div class="sl-item">
      <span class="sl-emoji">${s.emoji}</span>
      <div class="sl-info">
        <div>${s.rank}</div>
        <div class="sl-sub">${s.date}</div>
      </div>
      <span class="sl-meters">+${s.meters}m</span>
    </div>`).join('');
}
