// ===== GLOBAL UI =====
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2600);
}

function switchTab(name, btn) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const panel = document.getElementById('tab-' + name);
  if (panel) panel.classList.add('active');
  if (btn) btn.classList.add('active');

  // Lazy render per tab
  if (name === 'ranks') renderRanks();
  if (name === 'ambient') { renderSoundGrid(); renderMixControls(); }
  if (name === 'stats') renderStats();
  if (name === 'tasks') renderTasks();
  if (name === 'wisdom') renderWisdomHistory();

  // Close sidebar on mobile
  if (window.innerWidth <= 700) document.getElementById('sidebar').classList.remove('open');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function updateXpUI() {
  document.getElementById('xp-level').textContent = ST.level;
  document.getElementById('xp-cur').textContent = ST.xp;
  document.getElementById('xp-mini-fill').style.width = ST.xp + '%';
}

function updateSidebarRank() {
  const r = getCurrentRank();
  document.getElementById('sidebar-rank-emoji').textContent = r.emoji;
  document.getElementById('sidebar-rank-name').textContent = r.name;
  document.getElementById('sidebar-rank-meters').textContent = ST.totalMeters + 'm total';
}

function updateTimerStats() {
  document.getElementById('s-sessions').textContent = ST.sessions;
  document.getElementById('s-meters').textContent = ST.todayMeters + 'm';
  document.getElementById('s-streak').textContent = ST.streak + ' 🔥';
  document.getElementById('s-total').textContent = ST.totalMeters + 'm';
}

function updateAllUI() {
  updateXpUI();
  updateSidebarRank();
  updateTimerStats();
  renderTasks();
}

// ===== SPARKLES (heart/star drifters) =====
function buildSparkles() {
  const sf = document.getElementById('starfield');
  if (!sf) return;
  const sparks = ['💖','✨','🌸','⭐','💫','🎀','💕'];
  for (let i = 0; i < 12; i++) {
    const s = document.createElement('div');
    s.className = 'sparkle';
    s.textContent = sparks[i % sparks.length];
    s.style.cssText = `left:${Math.random()*100}%;top:${Math.random()*100}%;--sz:${8+Math.random()*8}px;--dur:${5+Math.random()*8}s;--delay:-${Math.random()*8}s;`;
    sf.appendChild(s);
  }
}

// ===== STARFIELD =====
function buildStarfield() {
  const sf = document.getElementById('starfield');
  if (!sf) return;
  const count = Math.min(120, Math.floor(window.innerWidth * window.innerHeight / 8000));
  sf.innerHTML = '';
  for (let i = 0; i < count; i++) {
    const s = document.createElement('div');
    s.className = 'star';
    const size = Math.random() * 2.5 + 0.5;
    const dur = (Math.random() * 4 + 2).toFixed(1);
    const delay = (Math.random() * 5).toFixed(1);
    const minOp = (Math.random() * 0.1 + 0.05).toFixed(2);
    const maxOp = (Math.random() * 0.5 + 0.2).toFixed(2);
    s.style.cssText = `
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      width: ${size}px;
      height: ${size}px;
      --dur: ${dur}s;
      --delay: -${delay}s;
      --min-op: ${minOp};
      --max-op: ${maxOp};
    `;
    sf.appendChild(s);
  }
}

// ===== DATE =====
function setDate() {
  const el = document.getElementById('panel-date');
  if (!el) return;
  el.textContent = new Date().toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  });
}

// ===== KEYBOARD SHORTCUTS =====
document.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  const key = e.key.toLowerCase();
  if (key === ' ' || e.code === 'Space') { e.preventDefault(); if (!isBreak) toggleTimer(); }
  if (key === 'r') resetTimer();
  if (key === 's') switchTab('stats', document.querySelector('[data-tab="stats"]'));
  if (key === 'w') switchTab('wisdom', document.querySelector('[data-tab="wisdom"]'));
  if (key === 't') switchTab('tasks', document.querySelector('[data-tab="tasks"]'));
  if (key === 'a') switchTab('ambient', document.querySelector('[data-tab="ambient"]'));
  if (key === 'escape') {
    document.getElementById('rank-modal').classList.remove('open');
    document.getElementById('sidebar').classList.remove('open');
  }
});

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  buildStarfield();
  buildSparkles();
  setDate();
  initKirby();
  updateAllUI();

  // Keyboard shortcut hint
  console.log('%c🌸 kirbs.pomodoro', 'font-size:18px;color:#e2b96f;font-weight:bold');
  console.log('%cShortcuts: Space=pause  R=reset  S=stats  W=wisdom  T=tasks  A=ambient', 'color:#9898b0');
});

window.addEventListener('resize', () => {
  updateKirbyPos();
  buildStarfield();
});
