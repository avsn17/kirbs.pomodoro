// ===== TIMER =====
let timerRunning = false;
let timerInterval = null;
let isBreak = false;
let breakInterval = null;

let goalMeters = 250;
let totalSecs = 250 * 6;  // 25 min
let elapsed = 0;
let remaining = totalSecs;
let breakRemaining = 300;

const KIRBY_IDLE   = 'idle';
const KIRBY_ACTIVE = 'active';
const KIRBY_PAUSED = 'paused';
const KIRBY_DONE   = 'done';
const KIRBY_BREAK  = 'break';

function setGoal(m, btn) {
  if (timerRunning) return;
  goalMeters = m;
  totalSecs = m * 6;
  remaining = totalSecs;
  elapsed = 0;

  document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
  if (btn) btn.classList.add('active');

  document.getElementById('prog-goal').textContent = m + 'm';
  updateTimerDisplay();
  updateKirbyPos();
}

function toggleTimer() {
  if (isBreak) return;
  timerRunning = !timerRunning;
  const btn = document.getElementById('start-btn');

  if (timerRunning) {
    btn.textContent = '⏸ PAUSE';
    setKirby(KIRBY_ACTIVE);
    setPhase('MISSION ACTIVE');
    timerInterval = setInterval(tick, 1000);
  } else {
    btn.textContent = '▶ RESUME';
    setKirby(KIRBY_PAUSED);
    setPhase('PAUSED — BREATHING');
    clearInterval(timerInterval);
  }
}

function tick() {
  if (remaining <= 0) { sessionComplete(); return; }
  remaining--;
  elapsed++;
  updateTimerDisplay();
  updateKirbyPos();
}

function updateTimerDisplay() {
  const m = Math.floor(remaining / 60);
  const s = remaining % 60;
  document.getElementById('timer-digits').textContent =
    String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');

  const meters = Math.round((elapsed / totalSecs) * goalMeters);
  document.getElementById('prog-dist').textContent = meters + 'm';
  const pct = totalSecs > 0 ? (elapsed / totalSecs) * 100 : 0;
  document.getElementById('prog-fill').style.width = pct + '%';
}

function updateKirbyPos() {
  const track = document.getElementById('kirby-track');
  if (!track) return;
  const pct = totalSecs > 0 ? elapsed / totalSecs : 0;
  const trackW = track.offsetWidth - 60;
  const pos = 4 + pct * trackW;
  document.getElementById('kirby-char').style.left = pos + 'px';
  document.getElementById('kirby-trail').style.width = pos + 'px';
}

function sessionComplete() {
  clearInterval(timerInterval);
  timerRunning = false;

  // Update state
  const prevTotal = ST.totalMeters;
  ST.totalMeters += goalMeters;
  ST.todayMeters += goalMeters;
  ST.sessions++;
  ST.sessionsTotal++;
  ST.streak++;
  ST.xp += 20;
  if (ST.xp >= 100) { ST.level++; ST.xp -= 100; showToast('⭐ Level ' + ST.level + '! POYO!'); }

  // Session log entry
  ST.sessionLog.unshift({
    emoji: getCurrentRank().emoji,
    meters: goalMeters,
    date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    rank: getCurrentRank().name,
  });
  if (ST.sessionLog.length > 20) ST.sessionLog = ST.sessionLog.slice(0, 20);

  saveState();
  checkRankUp(prevTotal, ST.totalMeters);
  updateAllUI();

  setKirby(KIRBY_DONE);
  setPhase('MISSION COMPLETE!! POYO!');
  document.getElementById('start-btn').textContent = '▶ START';

  showToast('🌺 +' + goalMeters + 'm earned! Great work!');
  fireConfetti();
  startBreak();
}

function startBreak() {
  isBreak = true;
  breakRemaining = 300;
  setKirby(KIRBY_BREAK);

  const banner = document.getElementById('break-banner');
  const skipBtn = document.getElementById('skip-btn');
  if (banner) banner.style.display = 'flex';
  if (skipBtn) skipBtn.style.display = '';

  breakInterval = setInterval(() => {
    breakRemaining--;
    const m = Math.floor(breakRemaining / 60);
    const s = breakRemaining % 60;
    const el = document.getElementById('bb-timer');
    if (el) el.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    if (breakRemaining <= 0) endBreak();
  }, 1000);
}

function endBreak() {
  clearInterval(breakInterval);
  isBreak = false;
  elapsed = 0;
  remaining = totalSecs;

  document.getElementById('break-banner').style.display = 'none';
  document.getElementById('skip-btn').style.display = 'none';
  setKirby(KIRBY_IDLE);
  setPhase('READY FOR NEXT MISSION');
  updateTimerDisplay();
  updateKirbyPos();
}

function skipBreak() {
  if (isBreak) { clearInterval(breakInterval); endBreak(); }
}

function resetTimer() {
  clearInterval(timerInterval);
  clearInterval(breakInterval);
  timerRunning = false;
  isBreak = false;
  elapsed = 0;
  remaining = totalSecs;

  document.getElementById('start-btn').textContent = '▶ START';
  document.getElementById('break-banner').style.display = 'none';
  document.getElementById('skip-btn').style.display = 'none';
  setKirby(KIRBY_IDLE);
  setPhase('READY TO LAUNCH');

  const char = document.getElementById('kirby-char');
  const trail = document.getElementById('kirby-trail');
  if (char) { char.style.transition = 'none'; char.style.left = '4px'; setTimeout(() => char.style.transition = '', 50); }
  if (trail) { trail.style.transition = 'none'; trail.style.width = '0px'; setTimeout(() => trail.style.transition = '', 50); }

  document.getElementById('prog-fill').style.width = '0%';
  document.getElementById('prog-dist').textContent = '0m';
  updateTimerDisplay();
}

function setKirby(mood) {
  setKirbyMood(mood);
  // track char emoji changes with mood
  const trackEmoji = { idle:'🌸', active:'💨', paused:'🌿', done:'🌺', break:'💤' };
  const el = document.getElementById('kirby-char');
  if (el) el.textContent = trackEmoji[mood] || '🌸';
  // pop stars on completion
  if (mood === 'done') {
    const timerKirby = document.getElementById('timer-kirby');
    if (timerKirby) spawnKirbyStars(timerKirby);
  }
}

function setPhase(text) {
  const el = document.getElementById('timer-phase');
  if (el) el.textContent = text;
}

// ===== RANK CHECK =====
function getCurrentRank() {
  return RANKS.filter(r => r.meters <= ST.totalMeters).pop() || RANKS[0];
}

function checkRankUp(before, after) {
  const prev = RANKS.filter(r => r.meters <= before).pop() || RANKS[0];
  const curr = getCurrentRank();
  if (curr.meters > prev.meters) {
    setTimeout(() => {
      document.getElementById('rm-emoji').textContent = curr.emoji;
      document.getElementById('rm-name').textContent = curr.name;
      document.getElementById('rm-sub').textContent = curr.meters + 'm traveled';
      document.getElementById('rank-modal').classList.add('open');
      document.getElementById('rank-modal').setAttribute('aria-hidden', 'false');
    }, 1200);
  }
}

function closeRankModal() {
  document.getElementById('rank-modal').classList.remove('open');
  document.getElementById('rank-modal').setAttribute('aria-hidden', 'true');
}

// ===== CONFETTI =====
function fireConfetti() {
  const canvas = document.getElementById('confetti-canvas');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.display = 'block';
  const ctx = canvas.getContext('2d');
  const colors = ['#e2b96f', '#7c5cbf', '#d4629a', '#5ab4c5', '#6B8F71'];
  const parts = Array.from({ length: 90 }, () => ({
    x: Math.random() * canvas.width,
    y: -10,
    vx: (Math.random() - 0.5) * 8,
    vy: Math.random() * 4 + 2,
    color: colors[Math.floor(Math.random() * colors.length)],
    size: Math.random() * 7 + 3,
    rot: Math.random() * 360,
    vr: (Math.random() - 0.5) * 12,
    shape: Math.random() > 0.5 ? 'rect' : 'circle',
  }));
  let frame = 0;
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    parts.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.vy += 0.06;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot * Math.PI / 180);
      ctx.fillStyle = p.color;
      if (p.shape === 'circle') { ctx.beginPath(); ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2); ctx.fill(); }
      else ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      ctx.restore();
    });
    frame++;
    if (frame < 130) requestAnimationFrame(draw);
    else canvas.style.display = 'none';
  }
  draw();
}
