// ===== TASKS =====
let taskFilter = 'all';

function renderTasks() {
  const list = document.getElementById('task-list');
  if (!list) return;
  const filtered = ST.tasks.filter(t => {
    if (taskFilter === 'active') return !t.done;
    if (taskFilter === 'done') return t.done;
    return true;
  });
  list.innerHTML = filtered.length === 0
    ? `<div style="text-align:center;color:var(--text3);font-size:13px;padding:2rem">No tasks here yet</div>`
    : filtered.map((t, i) => {
        const realIdx = ST.tasks.indexOf(t);
        return `<div class="task-item${t.done ? ' done' : ''}">
          <div class="task-check${t.done ? ' done' : ''}" onclick="inhaleTask(${realIdx})">${t.done ? '✓' : ''}</div>
          <span class="task-text${t.done ? ' done' : ''}">${escHtml(t.t)}</span>
          ${t.done ? '<span class="task-xp">+20 XP</span>' : ''}
          <button class="task-del" onclick="deleteTask(${realIdx})" aria-label="Delete">✕</button>
        </div>`;
      }).join('');

  // badge
  const active = ST.tasks.filter(t => !t.done).length;
  const badge = document.getElementById('task-badge');
  if (badge) badge.textContent = active;

  document.getElementById('done-count').textContent = ST.doneToday;
  document.getElementById('total-xp-earned').textContent = ST.totalXpEarned;
}

function inhaleTask(i) {
  if (ST.tasks[i]?.done) return;
  ST.tasks[i].done = true;
  ST.doneToday++;
  ST.xp += 20;
  ST.totalXpEarned += 20;
  if (ST.xp >= 100) { ST.level++; ST.xp -= 100; showToast('⭐ Level ' + ST.level + '! POYO!'); }
  saveState();
  updateXpUI();
  renderTasks();
  showToast('INHALE ✓ +20 XP');
  if (ST.tasks.every(t => t.done)) setTimeout(fireConfetti, 300);
}

function addTask() {
  const inp = document.getElementById('task-input');
  const t = inp.value.trim();
  if (!t) return;
  ST.tasks.push({ t, done: false });
  inp.value = '';
  saveState();
  renderTasks();
  showToast('Task added — POYO! 🌸');
}

function deleteTask(i) {
  ST.tasks.splice(i, 1);
  saveState();
  renderTasks();
}

function filterTasks(f, btn) {
  taskFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderTasks();
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
