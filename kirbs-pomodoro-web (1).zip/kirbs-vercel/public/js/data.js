// ===== RANKS =====
const RANKS = [
  { emoji: '🛸', name: 'Space Cadet',    meters: 0,    approx: 'Just starting' },
  { emoji: '🌙', name: 'Moon Walker',    meters: 100,  approx: '~10 minutes' },
  { emoji: '☄️',  name: 'Comet Rider',   meters: 500,  approx: '~50 minutes' },
  { emoji: '🚀', name: 'Orbit Master',   meters: 1000, approx: '~100 minutes' },
  { emoji: '⭐', name: 'Star Pilot',     meters: 2500, approx: '~250 minutes' },
  { emoji: '🌌', name: 'Galactic Overlord', meters: 5000, approx: '~500 minutes' },
];

// ===== WISDOM =====
const WISDOM = {
  iro: [
    { q: "Sometimes life is like this dark tunnel. You can't always see the light at the end, but if you keep moving, you will come to a better place.", s: "Uncle Iroh" },
    { q: "It is important to draw wisdom from many different places. If you take it from only one place, it becomes rigid and stale.", s: "Uncle Iroh" },
    { q: "While it is always best to believe in oneself, a little help from others can be a great blessing.", s: "Uncle Iroh" },
    { q: "You are stronger and wiser and freer than you have ever been. And now you have to look inward and begin asking yourself the big questions.", s: "Uncle Iroh" },
    { q: "Destiny is a funny thing. You never know how things are going to work out.", s: "Uncle Iroh" },
  ],
  bronte: [
    { q: "I'll walk where my own nature would be leading. It vexes me to choose another guide.", s: "Emily Brontë" },
    { q: "No coward soul is mine, no trembler in the world's storm-troubled sphere.", s: "Emily Brontë" },
    { q: "I have dreamed in my life dreams that have stayed with me ever after, and changed my ideas; they have gone through and through me, like wine through water.", s: "Emily Brontë, Wuthering Heights" },
    { q: "Every leaf speaks bliss to me, fluttering from the autumn tree.", s: "Emily Brontë" },
  ],
  kant: [
    { q: "Dare to know! Have the courage to use your own reason.", s: "Immanuel Kant" },
    { q: "Act only according to that maxim by which you can at the same time will that it should become a universal law.", s: "Immanuel Kant" },
    { q: "We are not rich by what we possess but by what we can do without.", s: "Immanuel Kant" },
    { q: "Out of the crooked timber of humanity, no straight thing was ever made.", s: "Immanuel Kant" },
  ],
  kirby: [
    { q: "Poyo.", s: "Kirby" },
    { q: "Poyo! Poyo poyo poyo!", s: "Kirby (very motivated)" },
    { q: "...poyo?", s: "Kirby (questioning the mission)" },
    { q: "POYO!!!", s: "Kirby (absolute banger energy)" },
    { q: "poyo poyo 🌸", s: "Kirby (sending good vibes)" },
    { q: "poyo. (you got this.)", s: "Kirby (quietly supportive)" },
  ],
  vibe: [
    { q: "main character energy activated. no notes.", s: "the vibes" },
    { q: "ur literally so close. keep going bestie.", s: "the universe (fr fr)" },
    { q: "it's giving growth. it's giving progress. it's giving you.", s: "cosmic energy" },
    { q: "romanticize the grind. make it cute. make it yours.", s: "your future self" },
    { q: "hot girl walk but make it focused study session.", s: "era check" },
    { q: "we don't give up. we take a five-minute break and recalibrate.", s: "the protocol" },
  ],
  heroic: [
    { q: "It does not matter how slowly you go as long as you do not stop.", s: "Confucius" },
    { q: "The secret of getting ahead is getting started.", s: "Mark Twain" },
    { q: "What lies behind us and before us are tiny matters compared to what lies within us.", s: "Ralph Waldo Emerson" },
    { q: "You miss one hundred percent of the shots you don't take.", s: "Wayne Gretzky" },
    { q: "Hard work beats talent when talent doesn't work hard.", s: "Tim Notke" },
  ],
  lyrics: [
    { q: "I'm starting with the man in the mirror — I'm asking him to change his ways.", s: "Michael Jackson, Man in the Mirror" },
    { q: "I was always an unusual girl. My mother told me I had a chameleon soul.", s: "Lana Del Rey, Ride" },
    { q: "You should be dancing, yeah.", s: "Bee Gees, You Should Be Dancing" },
    { q: "I don't want to be you anymore.", s: "Billie Eilish, idontwannabeyouanymore" },
    { q: "We can be heroes, just for one day.", s: "David Bowie, Heroes" },
    { q: "I want it all, I want it all, I want it all — and I want it now.", s: "Queen, I Want It All" },
  ],
  wisdom: [
    { q: "The present moment is the only moment available to us, and it is the door to all moments.", s: "Thich Nhat Hanh" },
    { q: "You are the sky. Everything else — it's just the weather.", s: "Pema Chödrön" },
    { q: "In the middle of difficulty lies opportunity.", s: "Albert Einstein" },
    { q: "Rest is not idleness — it is the letting go of all that is not essential.", s: "Unknown" },
    { q: "Almost everything will work again if you unplug it for a few minutes — including you.", s: "Anne Lamott" },
    { q: "Your present circumstances don't determine where you can go; they merely determine where you start.", s: "Nido Qubein" },
  ],
};

// ===== AMBIENT SOUNDS =====
const SOUNDS = [
  { id: 'rain',    name: 'Rain',       desc: 'Rainfall + thunder',   icon: '🌧️', type: 'rain'    },
  { id: 'forest',  name: 'Forest',     desc: 'Birds & wind',         icon: '🌲', type: 'forest'  },
  { id: 'fire',    name: 'Fireplace',  desc: 'Crackling warmth',     icon: '🔥', type: 'fire'    },
  { id: 'lullaby', name: 'Music Box',  desc: 'Dreamy melody',        icon: '🎀', type: 'lullaby' },
  { id: 'ocean',   name: 'Ocean',      desc: 'Waves + seagulls',     icon: '🌊', type: 'ocean'   },
  { id: 'space',   name: 'Space',      desc: 'Cosmic binaural hum',  icon: '🌌', type: 'space'   },
  { id: 'cafe',    name: 'Café',       desc: 'Jazz + chatter',       icon: '☕', type: 'cafe'    },
];

// ===== PERSISTENT STATE =====
function loadState() {
  try {
    const raw = localStorage.getItem('kirbs_state');
    const defaults = {
      totalMeters: 0,
      todayMeters: 0,
      sessions: 0,
      sessionsTotal: 0,
      streak: 0,
      xp: 0,
      level: 1,
      doneToday: 0,
      totalXpEarned: 0,
      tasks: [
        { t: 'Push kirbs.pomodoro to Vercel', done: false },
        { t: 'Conquer today\'s focus session', done: false },
        { t: 'Touch grass (mandatory)', done: false },
      ],
      sessionLog: [],
      wisdomHistory: [],
      lastDate: new Date().toDateString(),
    };
    if (!raw) return defaults;
    const saved = JSON.parse(raw);
    // Reset daily stats if new day
    if (saved.lastDate !== new Date().toDateString()) {
      saved.todayMeters = 0;
      saved.sessions = 0;
      saved.doneToday = 0;
      saved.lastDate = new Date().toDateString();
    }
    return { ...defaults, ...saved };
  } catch (e) { return {}; }
}

function saveState() {
  try { localStorage.setItem('kirbs_state', JSON.stringify(window.ST)); } catch(e) {}
}

window.ST = loadState();
