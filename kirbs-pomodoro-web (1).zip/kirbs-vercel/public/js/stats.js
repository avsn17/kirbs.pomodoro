// stats.js — delegates to renderStats() defined in ranks.js
// (kept as separate file to match index.html script tag)
