// ===== RICH AMBIENT SOUND ENGINE =====
let audioCtx = null;
const soundNodes = {};
const soundGains = {};
const activeSounds = new Set();

function getCtx() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}

function makeNoiseBuffer(ctx, seconds, pink) {
  const buf = ctx.createBuffer(2, ctx.sampleRate * seconds, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    if (!pink) {
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } else {
      let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
      for (let i = 0; i < d.length; i++) {
        const w = Math.random() * 2 - 1;
        b0=.99886*b0+w*.0555179; b1=.99332*b1+w*.0750759; b2=.96900*b2+w*.1538520;
        b3=.86650*b3+w*.3104856; b4=.55000*b4+w*.5329522; b5=-.7616*b5-w*.0168980;
        d[i]=(b0+b1+b2+b3+b4+b5+b6+w*.5362)*.11; b6=w*.115926;
      }
    }
  }
  return buf;
}

function makeReverb(ctx, dur, decay) {
  const len = ctx.sampleRate * dur;
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) d[i] = (Math.random()*2-1) * Math.pow(1-i/len, decay);
  }
  const conv = ctx.createConvolver(); conv.buffer = buf; return conv;
}

// ─── RAIN ────────────────────────────────────────────────────
function buildRain(ctx, master) {
  const nodes = [];
  const mist = ctx.createBufferSource();
  mist.buffer = makeNoiseBuffer(ctx, 4, true); mist.loop = true;
  const mf = ctx.createBiquadFilter(); mf.type='bandpass'; mf.frequency.value=1800; mf.Q.value=.6;
  const mg = ctx.createGain(); mg.gain.value=.35;
  mist.connect(mf); mf.connect(mg); mg.connect(master); mist.start(); nodes.push(mist);

  const drops = ctx.createBufferSource();
  drops.buffer = makeNoiseBuffer(ctx, 3, false); drops.loop = true;
  const df = ctx.createBiquadFilter(); df.type='lowpass'; df.frequency.value=900;
  const dg = ctx.createGain(); dg.gain.value=.22;
  const trem = ctx.createOscillator(); trem.type='sine'; trem.frequency.value=.9;
  const tremg = ctx.createGain(); tremg.gain.value=.09;
  trem.connect(tremg); tremg.connect(dg.gain);
  drops.connect(df); df.connect(dg); dg.connect(master); drops.start(); trem.start(); nodes.push(drops, trem);

  const rumble = ctx.createOscillator(); rumble.type='sawtooth'; rumble.frequency.value=50;
  const rf = ctx.createBiquadFilter(); rf.type='lowpass'; rf.frequency.value=110;
  const rg = ctx.createGain(); rg.gain.value=0;
  rumble.connect(rf); rf.connect(rg); rg.connect(master); rumble.start(); nodes.push(rumble);

  const rev = makeReverb(ctx, 2, 2);
  const rvg = ctx.createGain(); rvg.gain.value=.14;
  mf.connect(rev); rev.connect(rvg); rvg.connect(master);

  let running = true;
  function thunder() {
    if (!running) return;
    setTimeout(() => {
      if (!running) return;
      const t = ctx.currentTime;
      rg.gain.cancelScheduledValues(t);
      rg.gain.setValueAtTime(0, t);
      rg.gain.linearRampToValueAtTime(.055, t+.3);
      rg.gain.exponentialRampToValueAtTime(.001, t+4);
      thunder();
    }, 10000 + Math.random()*20000);
  }
  thunder();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

// ─── FOREST ──────────────────────────────────────────────────
function buildForest(ctx, master) {
  const nodes = [];
  const wind = ctx.createBufferSource();
  wind.buffer = makeNoiseBuffer(ctx, 5, true); wind.loop = true;
  const wf = ctx.createBiquadFilter(); wf.type='bandpass'; wf.frequency.value=600; wf.Q.value=.3;
  const wg = ctx.createGain(); wg.gain.value=.18;
  const wlfo = ctx.createOscillator(); wlfo.type='sine'; wlfo.frequency.value=.12;
  const wlfog = ctx.createGain(); wlfog.gain.value=.1;
  wlfo.connect(wlfog); wlfog.connect(wg.gain);
  wind.connect(wf); wf.connect(wg); wg.connect(master); wind.start(); wlfo.start(); nodes.push(wind, wlfo);

  const leaves = ctx.createBufferSource();
  leaves.buffer = makeNoiseBuffer(ctx, 3, true); leaves.loop = true;
  const lf = ctx.createBiquadFilter(); lf.type='highpass'; lf.frequency.value=3200;
  const lg = ctx.createGain(); lg.gain.value=.07;
  leaves.connect(lf); lf.connect(lg); lg.connect(master); leaves.start(); nodes.push(leaves);

  const rev = makeReverb(ctx, 3, 1.5);
  const rvg = ctx.createGain(); rvg.gain.value=.2;
  wf.connect(rev); rev.connect(rvg); rvg.connect(master);

  const birdFreqs = [2200,2800,3400,1800,2600,3100,2400];
  let running = true;
  function bird() {
    if (!running) return;
    setTimeout(() => {
      if (!running) return;
      const osc = ctx.createOscillator(); const g = ctx.createGain();
      const freq = birdFreqs[Math.floor(Math.random()*birdFreqs.length)];
      osc.type='sine'; osc.frequency.value=freq; g.gain.value=0;
      osc.connect(g); g.connect(rev); g.connect(master); osc.start();
      const t = ctx.currentTime;
      const n = 1 + Math.floor(Math.random()*3);
      for (let i=0; i<n; i++) {
        g.gain.setValueAtTime(0, t+i*.18);
        g.gain.linearRampToValueAtTime(.055, t+i*.18+.04);
        g.gain.linearRampToValueAtTime(0, t+i*.18+.12);
        osc.frequency.setValueAtTime(freq, t+i*.18);
        osc.frequency.linearRampToValueAtTime(freq*1.18, t+i*.18+.08);
      }
      setTimeout(()=>{try{osc.stop();}catch(e){}}, n*200+200);
      bird();
    }, 1500 + Math.random()*5000);
  }
  bird();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

// ─── FIRE ────────────────────────────────────────────────────
function buildFire(ctx, master) {
  const nodes = [];
  const crack = ctx.createBufferSource();
  crack.buffer = makeNoiseBuffer(ctx, 2, true); crack.loop = true;
  const cf = ctx.createBiquadFilter(); cf.type='lowpass'; cf.frequency.value=500;
  const cg = ctx.createGain(); cg.gain.value=.3;
  crack.connect(cf); cf.connect(cg); cg.connect(master); crack.start(); nodes.push(crack);

  const roar = ctx.createBufferSource();
  roar.buffer = makeNoiseBuffer(ctx, 4, false); roar.loop = true;
  const rf = ctx.createBiquadFilter(); rf.type='bandpass'; rf.frequency.value=200; rf.Q.value=1;
  const rg = ctx.createGain(); rg.gain.value=.2;
  const rlfo = ctx.createOscillator(); rlfo.type='sine'; rlfo.frequency.value=.35;
  const rlfog = ctx.createGain(); rlfog.gain.value=.08;
  rlfo.connect(rlfog); rlfog.connect(rg.gain);
  roar.connect(rf); rf.connect(rg); rg.connect(master); roar.start(); rlfo.start(); nodes.push(roar, rlfo);

  const pop = ctx.createBufferSource();
  pop.buffer = makeNoiseBuffer(ctx, 1, false); pop.loop = true;
  const pf = ctx.createBiquadFilter(); pf.type='highpass'; pf.frequency.value=2200;
  const pg = ctx.createGain(); pg.gain.value=.04;
  const plfo = ctx.createOscillator(); plfo.type='sawtooth'; plfo.frequency.value=2.3;
  const plfog = ctx.createGain(); plfog.gain.value=.035;
  plfo.connect(plfog); plfog.connect(pg.gain);
  pop.connect(pf); pf.connect(pg); pg.connect(master); pop.start(); plfo.start(); nodes.push(pop, plfo);
  return { nodes, gain: master, stop: () => nodes.forEach(n=>{try{n.stop();}catch(e){}}) };
}

// ─── LULLABY / MUSIC BOX ─────────────────────────────────────
function buildLullaby(ctx, master) {
  const nodes = [];
  const scale = [261.63,293.66,329.63,349.23,392.00,440.00,493.88,523.25];
  const rev = makeReverb(ctx, 3, 1.8);
  const rvg = ctx.createGain(); rvg.gain.value=.5;
  rev.connect(rvg); rvg.connect(master);

  const pad = ctx.createOscillator(); pad.type='sine'; pad.frequency.value=130.81;
  const padg = ctx.createGain(); padg.gain.value=.055;
  const padf = ctx.createBiquadFilter(); padf.type='lowpass'; padf.frequency.value=380;
  pad.connect(padf); padf.connect(padg); padg.connect(master); pad.start(); nodes.push(pad);

  let running = true;
  function note() {
    if (!running) return;
    const freq = scale[Math.floor(Math.random()*scale.length)];
    const osc = ctx.createOscillator(); const g = ctx.createGain();
    osc.type = Math.random()>.65 ? 'triangle' : 'sine';
    osc.frequency.value = freq * (Math.random()>.55 ? 2 : 1);
    const t = ctx.currentTime;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(.075, t+.05);
    g.gain.exponentialRampToValueAtTime(.001, t+1.5);
    osc.connect(g); g.connect(rev); g.connect(master);
    osc.start(); osc.stop(t+1.6); nodes.push(osc);
    setTimeout(note, 550 + Math.random()*900);
  }
  note();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

// ─── OCEAN ───────────────────────────────────────────────────
function buildOcean(ctx, master) {
  const nodes = [];
  const wave = ctx.createBufferSource();
  wave.buffer = makeNoiseBuffer(ctx, 6, true); wave.loop = true;
  const wf = ctx.createBiquadFilter(); wf.type='lowpass'; wf.frequency.value=1100;
  const wg = ctx.createGain(); wg.gain.value=.25;
  const wlfo = ctx.createOscillator(); wlfo.type='sine'; wlfo.frequency.value=.12;
  const wlfog = ctx.createGain(); wlfog.gain.value=.2;
  wlfo.connect(wlfog); wlfog.connect(wg.gain);
  wave.connect(wf); wf.connect(wg); wg.connect(master); wave.start(); wlfo.start(); nodes.push(wave, wlfo);

  const bass = ctx.createOscillator(); bass.type='sine'; bass.frequency.value=58;
  const bg = ctx.createGain(); bg.gain.value=.065;
  const blfo = ctx.createOscillator(); blfo.type='sine'; blfo.frequency.value=.08;
  const blfog = ctx.createGain(); blfog.gain.value=.055;
  blfo.connect(blfog); blfog.connect(bg.gain);
  bass.connect(bg); bg.connect(master); bass.start(); blfo.start(); nodes.push(bass, blfo);

  const rev = makeReverb(ctx, 2.5, 1.5);
  const rvg = ctx.createGain(); rvg.gain.value=.2;
  wf.connect(rev); rev.connect(rvg); rvg.connect(master);

  let running = true;
  function gull() {
    if (!running) return;
    setTimeout(() => {
      if (!running) return;
      const osc = ctx.createOscillator(); osc.type='sine';
      const g = ctx.createGain(); const t = ctx.currentTime;
      osc.frequency.setValueAtTime(1400, t);
      osc.frequency.linearRampToValueAtTime(1900, t+.3);
      osc.frequency.linearRampToValueAtTime(1600, t+.6);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(.03, t+.15);
      g.gain.exponentialRampToValueAtTime(.001, t+.7);
      osc.connect(g); g.connect(master); osc.start(); osc.stop(t+.8);
      gull();
    }, 7000 + Math.random()*18000);
  }
  gull();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

// ─── SPACE ───────────────────────────────────────────────────
function buildSpace(ctx, master) {
  const nodes = [];
  [[55,.12],[55.3,.11],[110,.04],[82.4,.06]].forEach(([f,v]) => {
    const o = ctx.createOscillator(); o.type='sine'; o.frequency.value=f;
    const g = ctx.createGain(); g.gain.value=v;
    o.connect(g); g.connect(master); o.start(); nodes.push(o);
  });
  const wh = ctx.createBufferSource();
  wh.buffer = makeNoiseBuffer(ctx, 5, true); wh.loop = true;
  const whf = ctx.createBiquadFilter(); whf.type='bandpass'; whf.frequency.value=300; whf.Q.value=.4;
  const whg = ctx.createGain(); whg.gain.value=.055;
  const whlfo = ctx.createOscillator(); whlfo.type='sine'; whlfo.frequency.value=.04;
  const whlfog = ctx.createGain(); whlfog.gain.value=.05;
  whlfo.connect(whlfog); whlfog.connect(whg.gain);
  wh.connect(whf); whf.connect(whg); whg.connect(master); wh.start(); whlfo.start(); nodes.push(wh, whlfo);
  let running = true;
  function shimmer() {
    if (!running) return;
    setTimeout(() => {
      if (!running) return;
      const osc = ctx.createOscillator(); const g = ctx.createGain(); const t = ctx.currentTime;
      osc.type='sine'; osc.frequency.value=3000+Math.random()*4000;
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.022,t+.03); g.gain.exponentialRampToValueAtTime(.001,t+1.2);
      osc.connect(g); g.connect(master); osc.start(); osc.stop(t+1.3);
      shimmer();
    }, 2000+Math.random()*5000);
  }
  shimmer();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

// ─── CAFÉ ────────────────────────────────────────────────────
function buildCafe(ctx, master) {
  const nodes = [];
  const mur = ctx.createBufferSource();
  mur.buffer = makeNoiseBuffer(ctx, 6, true); mur.loop = true;
  const mf = ctx.createBiquadFilter(); mf.type='bandpass'; mf.frequency.value=700; mf.Q.value=.2;
  const mg = ctx.createGain(); mg.gain.value=.1;
  mur.connect(mf); mf.connect(mg); mg.connect(master); mur.start(); nodes.push(mur);
  let running = true;
  function clink() {
    if (!running) return;
    setTimeout(() => {
      if (!running) return;
      const osc = ctx.createOscillator(); const g = ctx.createGain(); const t = ctx.currentTime;
      osc.type='sine'; osc.frequency.value=1200+Math.random()*800;
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.038,t+.01); g.gain.exponentialRampToValueAtTime(.001,t+.75);
      osc.connect(g); g.connect(master); osc.start(); osc.stop(t+.8);
      clink();
    }, 5000+Math.random()*10000);
  }
  clink();
  const jNotes = [220,261.63,329.63,392,349.23];
  let ji=0;
  function jazz() {
    if (!running) return;
    const osc = ctx.createOscillator(); osc.type='triangle';
    const g = ctx.createGain(); const filt = ctx.createBiquadFilter(); filt.type='lowpass'; filt.frequency.value=750;
    const t = ctx.currentTime;
    osc.frequency.value = jNotes[ji%jNotes.length]*(Math.random()>.8?2:1); ji++;
    g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.02,t+.1); g.gain.exponentialRampToValueAtTime(.001,t+.9);
    osc.connect(filt); filt.connect(g); g.connect(master); osc.start(); osc.stop(t+1);
    setTimeout(jazz, 700+Math.random()*600);
  }
  jazz();
  return { nodes, gain: master, stop: () => { running=false; nodes.forEach(n=>{try{n.stop();}catch(e){}}) }};
}

const BUILDERS = { rain:buildRain, forest:buildForest, fire:buildFire, lullaby:buildLullaby, ocean:buildOcean, space:buildSpace, cafe:buildCafe };

function toggleSound(id) {
  if (activeSounds.has(id)) { stopSound(id); return; }
  const ctx = getCtx();
  const master = ctx.createGain(); master.gain.value=.3; master.connect(ctx.destination);
  const s = SOUNDS.find(x=>x.id===id); if (!s) return;
  soundNodes[id] = BUILDERS[s.type]?.(ctx, master) || null;
  soundGains[id] = master;
  activeSounds.add(id);
  document.querySelector(`[data-sid="${id}"]`)?.classList.add('playing');
  updateAmbientUI(); renderMixControls();
  showToast(`${s.icon} ${s.name} playing`);
}

function stopSound(id) {
  try { soundNodes[id]?.stop?.(); soundNodes[id]?.nodes?.forEach(n=>{try{n.stop();}catch(e){}}); } catch(e){}
  try { soundGains[id]?.disconnect(); } catch(e){}
  delete soundNodes[id]; delete soundGains[id];
  activeSounds.delete(id);
  document.querySelector(`[data-sid="${id}"]`)?.classList.remove('playing');
  updateAmbientUI(); renderMixControls();
}

function stopAllSounds() { [...activeSounds].forEach(stopSound); showToast('All sounds stopped ✨'); }

function setVol(id, val) {
  if (soundGains[id]) soundGains[id].gain.value = val/100;
  const el = document.getElementById('mixval-'+id); if (el) el.textContent=val;
}

function updateAmbientUI() {
  const names = [...activeSounds].map(id=>{ const s=SOUNDS.find(x=>x.id===id); return s?`<strong>${s.icon} ${s.name}</strong>`:''; }).join(', ');
  const el = document.getElementById('np-text'); if (el) el.innerHTML=activeSounds.size?names:'Nothing playing';
  document.querySelectorAll('.np-bar').forEach(b=>activeSounds.size?b.classList.add('active'):b.classList.remove('active'));
  const dot=document.getElementById('ambient-dot'); if(dot) dot.style.display=activeSounds.size>0?'block':'none';
}

function renderMixControls() {
  const el=document.getElementById('mix-controls'); if (!el) return;
  if (!activeSounds.size) { el.innerHTML='<div class="mix-empty">Play a sound above to mix volumes 🎀</div>'; return; }
  el.innerHTML=[...activeSounds].map(id=>{
    const s=SOUNDS.find(x=>x.id===id);
    const vol=soundGains[id]?Math.round(soundGains[id].gain.value*100):30;
    return `<div class="mix-row"><span class="mix-icon">${s.icon}</span><span class="mix-name">${s.name}</span>
    <input type="range" class="mix-slider" min="0" max="100" value="${vol}" step="1" oninput="setVol('${id}',this.value)">
    <span class="mix-val" id="mixval-${id}">${vol}</span></div>`;
  }).join('');
}

function renderSoundGrid() {
  const grid=document.getElementById('sound-grid'); if (!grid) return;
  grid.innerHTML=SOUNDS.map(s=>`<div class="sound-card${activeSounds.has(s.id)?' playing':''}" data-sid="${s.id}" onclick="toggleSound('${s.id}')">
    <span class="sound-icon">${s.icon}</span><div class="sound-name">${s.name}</div><div class="sound-desc">${s.desc}</div></div>`).join('');
}
